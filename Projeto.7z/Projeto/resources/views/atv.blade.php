@extends('common.basic-template')

@section('content')



@component('components.topo')
@endcomponent

@component('components.texto')
@endcomponent

@component('components.cadastro')
@endcomponent

@component('components.rodape')
@endcomponent











