
@include('common.cabecario');

@yield('content');

@include('common.rodape');