
  <script type="text/javascript" src="{{asset('public/mdb/js/jquery.min.js')}}"></script>
  <script type="text/javascript" src="{{asset('public/mdb/js/popper.min.js')}}"></script>
  <script type="text/javascript" src="{{asset('public/mdb/js/bootstrap.min.js')}}"></script>
  <script type="text/javascript" src="{{asset('public/mdb/js/mdb.min.js')}}"></script>
  <script type="text/javascript"></script>

</body>
</html>