
    <h1 class="font-weight-bold text-center h1 my-5 {{$textcolor}}">{{ $title }}</h1>

    <p class="text-center grey-text mb-5 mx-auto w-responsive lead">{{$body}}</p>