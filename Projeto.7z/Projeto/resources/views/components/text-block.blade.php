            <!--Grid row-->
            <div class="row mb-2">
              <div class="col-2">
                <i class="fas fa-2x {{$icon}} {{$textcolor}}"></i>
              </div>
              <div class="col-10">
                <h5 class="font-weight-bold mb-4">{{$title}}</h5>
                <p class="grey-text">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Reprehenderit maiores
                  nam, aperiam minima assumenda.</p>
              </div>
            </div>
            <!--Grid row-->
