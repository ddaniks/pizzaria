<center>





<p> Este bolo foi feito com prosito de arrecadas fundos para projeto social seninha fome zero
    as vendas seram revertidas em mantimentos para familia carentes afetadas pela chuvas no litoral paulista </p>

    <button class="btn purple-gradient">COMPRAR</button>
</center>